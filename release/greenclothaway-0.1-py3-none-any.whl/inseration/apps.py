from django.apps import AppConfig


class InserationConfig(AppConfig):
    name = 'inseration'
